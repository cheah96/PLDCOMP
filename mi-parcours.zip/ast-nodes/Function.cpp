#include "Function.h"

/*Function::Function(DefFunc* oneDef){
    type = DEFINITION;
    def = oneDef;
    dec = nullptr;
}
      
Function::Function(DecFunc* oneDec){
    type = DECLARATION;
    def = nullptr;
    dec = oneDec;
}*/