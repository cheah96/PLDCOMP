#pragma once
#include <string>
#include <fstream>
#include <vector>
#include "Type.h"
//#include "DecFunc.h"
using namespace std;

class CFG;

class Parameter;

/*Node which represents a function (a declaration of function or a definition of function)*/

class Function{
    public:
        Function(string oneName, Type* oneType) : name(oneName), returnType(oneType){}
        virtual ~Function(){}
        virtual void addParameter(Parameter* param) = 0;
	/*Creates the correspondant IR instruction of this node in CFG*/
        virtual string buildIR(CFG* cfg) = 0;
        virtual string getName() = 0;

    protected:
	    string name;
    	Type* returnType;
    	vector<Parameter*> params;
};
