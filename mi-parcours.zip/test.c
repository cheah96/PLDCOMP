int main(){
	int x,y;
	x=2+3;
	y = 1+x;
	y = y + x;
	y = y * (x + 3);
	putchar('Z');
	putchar('h');
	putchar('e');
	putchar('n');
	putchar('y');
	putchar('u');
	putchar(' ');
	putchar('\b');
	putchar('b');
	putchar('e');
	putchar('a');
	putchar('u');
	putchar(' ');
	char c = '!';
	putchar(c);
	putchar('\n');
	return y;
}
