int main(){
	int x = 3;
	int y = 4;
	int z = x/y;
	return z;
}
