int main(int arg){
	int x,y;
	x=2+3;
	y = 1+x;
	y = y + x;
	y = 2 * (x + 3);
	x = x * y;
	char c = 'a';
	putchar(c);
	putchar('b');
	putchar('\n');
	return x/15;
}
